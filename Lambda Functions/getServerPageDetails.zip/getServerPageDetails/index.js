
 var mysql = require("mysql");
exports.handler = (event, context) => {
   console.log(" Function start for DB interaction ");
    var con = mysql.createConnection({
    host: "infraguarddb.cvfgxhprsmji.us-west-2.rds.amazonaws.com",
    user: "avignadev",
    password: "avIgnaDev3",
    database: "InfraDB"
    });
    
var projectId = event.projectId;
	var obj = {};
	Promise.all([
		new Promise((resolve, reject) => {
			con.query("select * from projectdetails where id = ? ",projectId, function(err, result) {
				if(err)console.log(err.stack);
				if(result.length > 0){
					resolve(result[0]);
				}
				resolve(null);
			});
		}),
		new Promise((resolve, reject) => {
				con.query("SELECT * FROM servers WHERE project_id = ? ",projectId, function(err, result){
					if(err)console.log(err.stack);
						if(result.length > 0){
							resolve(result);
						}
						resolve(null);
					});
			})
	])
	.then((results) => {
		obj.project = results[0];
		obj.servers = results[1];
		//res.status(200).json(obj);
		context.succeed(obj);
	});
    
    con.end(function(err) {
     console.log("connection closed");
	   });
 };
