
 var mysql = require("mysql");
exports.handler = (event, context) => {
   console.log(" Function start for DB interaction ");
    var con = mysql.createConnection({
    host: "infraguarddb.cvfgxhprsmji.us-west-2.rds.amazonaws.com",
    user: "avignadev",
    password: "avIgnaDev3",
    database: "InfraDB"
    });
    
var id = parseInt(event.id);
var status = parseInt(event.status);
var serverIp = event.serverIp;
var userName = event.userName;
var userList ="";
function removeValue(list, value) {
  return list.replace(new RegExp(",?" + value + ",?"), function(match) {
      var first_comma = match.charAt(0) === ',',
          second_comma;

      if (first_comma &&
          (second_comma = match.charAt(match.length - 1) === ',')) {
        return ',';
      }
      return '';
    });
};
con.connect();

if(status==0){
Promise.all([
	new Promise((resolve, reject) => {
		con.query("select userList from servers where serverIp = ? ",serverIp, function(err, result) {
			if(err)console.log(err.stack);
			if(result.length > 0){
                 userList=result[0].userList;
				// userList=userList+","+userName;
				userList = removeValue(userList, userName);
				 console.log("25. userList = : "+userList);
				con.query("update servers set userList = ? where serverIp = ? ",[userList,serverIp], function(err, result) {
					if(err)console.log(err.stack);
					});
				}
			});
	}),
      new Promise((resolve, reject) => {
             con.query("update agentActivities set status = ? where id = ? ",[1,id], function(err, result) {
					if(err)console.log(err.stack);
					
					});
	 })
])
.then((results) => {
		context.succeed("userDeleted and activity updated");
	});
}
    
    //con.end(function(err) {
     //console.log("connection closed");
	 //  });
 };