
 var mysql = require("mysql");
exports.handler = (event, context) => {
   console.log(" Function start for DB interaction ");
    var con = mysql.createConnection({
    host: "infraguarddb.cvfgxhprsmji.us-west-2.rds.amazonaws.com",
    user: "avignadev",
    password: "avIgnaDev3",
    database: "InfraDB"
    });
    
var companyId = event.companyId;
var obj = {};
Promise.all([
	new Promise((resolve, reject) => {
		con.query("select * from companydetails where id = ? ",companyId, function(err, result) {
			if(err)console.log(err.stack);
			if(result.length > 0){
				resolve(result[0]);
			}
			resolve(null);
		});
	}),
	new Promise((resolve, reject) => {
			con.query("SELECT * FROM projectdetails WHERE company_id = ? ",companyId, function(err, result){
				if(err)console.log(err.stack);
					if(result.length > 0){
						resolve(result);
					}
					resolve(null);
					
				});
			
		}),
	new Promise((resolve, reject) => {
			con.query("SELECT * FROM projectdetails p INNER JOIN servers s ON p.id = s.project_id WHERE p.company_id = ? ",companyId, function(err, result){
				if(err)console.log(err.stack);
				if(result.length > 0){
					resolve(result);
				}
				resolve(null);
			});
		})
	

])
.then((results) => {
	obj.company = results[0];
	obj.projects = results[1];
	obj.servers = results[2];
	//res.status(200).json(obj);
	context.succeed(obj);
});
    
    con.end(function(err) {
     console.log("connection closed");
	   });
 };
