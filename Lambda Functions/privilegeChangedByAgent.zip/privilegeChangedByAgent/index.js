
var mysql = require("mysql");
exports.handler = (event, context) => {
    var con = mysql.createConnection({
    host: "infraguarddb.cvfgxhprsmji.us-west-2.rds.amazonaws.com",
    user: "avignadev",
    password: "avIgnaDev3",
    database: "InfraDB"
    });
    
var id = parseInt(event.id);
var status = parseInt(event.status);
var serverIp = event.serverIp;
var userName = event.userName;
var privilege = event.privilege;
var password = event.password;
var mailId ="";
con.connect();
if(status==0){
Promise.all([
	new Promise((resolve, reject) => {
	if( password != undefined && password.length > 0 ){
		con.query("select email from users where uname = ?",[userName], function(err, result) {
			if(err)console.log(err.stack);
			if(result.length > 0){
                 mailId=result[0].email;
				}
			});
		}
		resolve(null);
	}),
      new Promise((resolve, reject) => {
             con.query("update agentActivities set status = ? where id = ? ",[1,id], function(err, result) {
					if(err)console.log(err.stack);
					resolve(null);
					});
	 })
])
.then((results) => {
		
		if( password != undefined && password.length > 0 ){

		var aws = require('aws-sdk');
		var ses = new aws.SES({
		   region: 'us-east-1'
		});

		var eParams = {
			Destination: {
				ToAddresses: [mailId]
			},
			Message: {
				Body: {
					Text: {
						Data: "Welcome to Infraguard.Below is your password for server sudo access, keep it safe.\n\n ServerIp : "+serverIp+"\n Password :  "+password+" \n\n Thanks \n Infraguard Team"
					}
				},
				Subject: {
					Data: "Server Sudo Credentials"
				}
			},
		Source: "pratyush.pk3@gmail.com"
     };
       var email = ses.sendEmail(eParams, function(err, data){
			if(err) console.log(err);
			else {
				context.succeed(" user sudo password mailed "+event);
			}
		});
	} else {
     context.succeed("userPrivilege changed and activity updated");
	}
	});
} else {
       context.succeed("No activity status = 1");
      }
    
    //con.end(function(err) {
     //console.log("connection closed");
	 //  });
 };