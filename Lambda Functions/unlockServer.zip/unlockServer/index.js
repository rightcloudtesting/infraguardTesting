
var mysql = require("mysql");
exports.handler = (event, context) => {
   
	var con = mysql.createConnection({
    host: "infraguarddb.cvfgxhprsmji.us-west-2.rds.amazonaws.com",
    user: "avignadev",
    password: "avIgnaDev3",
    database: "InfraDB"
    });
    
	var id = parseInt(event.id);
	var status = parseInt(event.status);
	var serverIp = event.serverIp;
	con.connect();
if(status==0){
	Promise.all([
		new Promise((resolve, reject) => {
			con.query("update servers set lockedDown = ? where serverIp = ? ",[0,serverIp], function(err, result) {
						if(err)console.log(err.stack);
						resolve(null);
						});
		}),
		  new Promise((resolve, reject) => {
				 con.query("update agentActivities set status = ? where id = ? ",[1,id], function(err, result) {
						if(err)console.log(err.stack);
						resolve(null);
						});
		 })
   ])
   .then((results) => {
			context.succeed("Server Unlocked and activity updated");
			});
 }
};