
 var mysql = require("mysql");
exports.handler = (event, context) => {
   console.log(" Function start for DB interaction ");
    var con = mysql.createConnection({
    host: "ig.cwsxvthadvpw.ap-southeast-1.rds.amazonaws.com",
    user: "igapp",
    password: "n*JoEHl8OT9w",
    database: "ig",
    port : 3307
    });
    
var id = parseInt(event.id);
var status = parseInt(event.status);
var serverIp = event.serverIp;
var userName = event.userName;

con.connect();
if(status==0){
Promise.all([
	new Promise((resolve, reject) => {
		con.query("insert into userServerAccessStatus (serverIP,userName,accessStatus) values (?,?,1) ON DUPLICATE KEY UPDATE accessStatus = 1 ",[serverIp,userName], function(err, result) {
			if(err)console.log(err.stack);
			resolve(null);
		});
	}),
      new Promise((resolve, reject) => {
             con.query("update agentActivities set status = ? where id = ? ",[1,id], function(err, result) {
					if(err)console.log(err.stack);
					resolve(null);
				});
	  })
])
.then((results) => {
		context.succeed("accessGranted  and activity updated");
	});
}
    
    //con.end(function(err) {
     //console.log("connection closed");
	 //  });
 };