
 var mysql = require("mysql");
exports.handler = (event, context) => {
   console.log(" Function start for DB interaction ");
    var con = mysql.createConnection({
    host: "infraguarddb.cvfgxhprsmji.us-west-2.rds.amazonaws.com",
    user: "avignadev",
    password: "avIgnaDev3",
    database: "InfraDB"
    });
    
var id = parseInt(event.id);
var status = parseInt(event.status);
var serverIp = event.serverIp;
var userName = event.userName;
var userList ="";
con.connect();
if(status==0){
Promise.all([
	new Promise((resolve, reject) => {
		con.query("select userList from servers where serverIp = ? ",serverIp, function(err, result) {

			if(err)console.log(err.stack);
			if(result.length > 0){
                 userList=result[0].userList;
				 userList=userList+","+userName;
				 console.log("25. userList = : "+userList);
				con.query("update servers set userList = ? where serverIp = ? ",[userList,serverIp], function(err, result) {
					if(err)console.log(err.stack);
					//if(result.length > 0){
						//resolve(result);
				console.log("30. result = : "+ JSON.stringify(result));
						//}else{
						//resolve(null);
						//}
					});
				//resolve(result);
				//console.log("userList = : "+ userList);
			}
			resolve(null);
		});
	}),
      new Promise((resolve, reject) => {
             con.query("update agentActivities set status = ? where id = ? ",[1,id], function(err, result) {
					if(err)console.log(err.stack);
					
					});
	})
])
.then((results) => {
		context.succeed("userAdded and activity updated");
	});
}
    
    //con.end(function(err) {
     //console.log("connection closed");
	 //  });
 };