
 var mysql = require("mysql");
exports.handler = (event, context) => {
   console.log(" Function start for DB interaction ");
    var con = mysql.createConnection({
    host: "infraguarddb.cvfgxhprsmji.us-west-2.rds.amazonaws.com",
    user: "avignadev",
    password: "avIgnaDev3",
    database: "InfraDB"
    });
    
var serverIp = event.serverIp;
Promise.all([
	new Promise((resolve, reject) => {
		con.query("select activityName,requiredData,convert(id,char(10)) as id from agentActivities where serverIp = ? and status = ?",[serverIp,0], function(err, result) {
			if(err)console.log(err.stack);
			if(result.length > 0){
				resolve(result);
			}
			resolve(null);
		});
	})
])
.then((results) => {
		context.succeed(results[0]);
	});
    
    con.end(function(err) {
     console.log("connection closed");
	   });
 };
